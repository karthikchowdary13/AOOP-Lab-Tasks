package Library;

import java.util.ArrayList;
import java.util.Collections;
import java.util.Iterator;
import java.util.List;

public class Library {
    private List<Book> books;

    public Library() {
        this.books = new ArrayList<>();
    }

    public void addBook(Book book) {
        books.add(book);
    }

    public List<Book> getBooks() {  // Add this method
        return books;
    }

    public void sortByTitle() {
        Collections.sort(books);
    }

    public void sortByAuthor() {
        Collections.sort(books, new BookComparator());
    }

    public void displayBooks() {
        Iterator<Book> iterator = books.iterator();
        while (iterator.hasNext()) {
            System.out.println(iterator.next());
        }
    }

    public Book cloneBook(Book book) throws CloneNotSupportedException {
        return (Book) book.clone();
    }
}
