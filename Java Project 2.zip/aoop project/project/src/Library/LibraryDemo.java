package Library;

public class LibraryDemo {

	public static void main(String[] args) {
		        Library library = new Library();

		        // Adding books to the library
		        library.addBook(new Book("The Great Gatsby", "F. Scott Fitzgerald", 1925));
		        library.addBook(new Book("1984", "George Orwell", 1949));
		        library.addBook(new Book("To Kill a Mockingbird", "Harper Lee", 1960));
		        library.addBook(new Book("Moby Dick", "Herman Melville", 1851));

		        System.out.println("Books sorted by title:");
		        library.sortByTitle();
		        library.displayBooks();

		        System.out.println("\nBooks sorted by author:");
		        library.sortByAuthor();
		        library.displayBooks();

		        try {
		            Book clonedBook = library.cloneBook(library.getBooks().get(0));
		            System.out.println("\nCloned Book: " + clonedBook);
		        } catch (CloneNotSupportedException e) {
		            e.printStackTrace();
		        }
		    }
		}
